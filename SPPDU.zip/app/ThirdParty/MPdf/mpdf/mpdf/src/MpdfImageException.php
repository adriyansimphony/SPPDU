<?php

namespace Mpdf;

class MpdfImageException extends \Mpdf\MpdfException
{

}

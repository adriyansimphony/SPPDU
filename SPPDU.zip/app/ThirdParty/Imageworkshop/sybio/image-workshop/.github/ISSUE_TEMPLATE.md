| Q                | A
| ---------------- | -----
| Bug report?      | yes/no
| Feature request? | yes/no
| Usage question?  | yes/no
| PHP version used | x.y

<!--
- Please fill in this template according to your issue.
- Otherwise, replace this comment by the description of your issue.
-->
